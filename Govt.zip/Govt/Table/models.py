from django.db import models

# Create your models here.
class Customer(models.Model):
    NID= models.CharField('NID', max_length=50,null=True,blank=True)
    RCOUNT= models.CharField('RCOUNT', max_length=50,null=True,blank=True)
    PASSWORD=models.CharField('Password',max_length=35,null=True,blank=True)
    IS_ACTIVATED=models.BooleanField("IsActivated",default=False)
    
class Customer_info(models.Model):
    NAME = models.CharField('Name', max_length=50,null=True,blank=True)
    DATE_OF_BIRTH = models.DateField('DateOfBirth',null=True,blank=True)
    PHONE = models.CharField('Phone', max_length=50,null=True,blank=True)
    ADDRESS= models.CharField('Address', max_length=50,null=True,blank=True)
    NID= models.CharField('NID', max_length=50,null=True,blank=True)

class Vat_info(models.Model):
    VAT_TYPE=models.CharField('VATType', max_length=50,null=True,blank=True)
    VAT_PERCENTAGE= models.CharField('VATPercentage', max_length=50,null=True,blank=True)
    
class Business_info(models.Model):
    BUSINESS_ID= models.CharField('Business_ID', max_length=50,null=True,blank=True)
    ADDRESS= models.CharField('Address', max_length=50,null=True,blank=True)
    PHONE = models.CharField('Phone', max_length=50,null=True,blank=True)
    VAT_ID= models.CharField('VAT_ID', max_length=50,null=True,blank=True)
    VAT_TYPE=models.ForeignKey(Vat_info, max_length=35,null=True,blank=True)
    
class Invoice(models.Model):
    VAT_NO=models.CharField('VAT_ID', max_length=50,null=True,blank=True)
    BUSINESS_ID= models.CharField('Business_ID', max_length=50,null=True,blank=True)
    INVOICE_ID= models.CharField('Invoice_ID', max_length=50,null=True,blank=True)
    DATE= models.DateField('DateOfCreation',null=True,blank=True)
    PRICE= models.CharField('Price', max_length=50,null=True,blank=True)
    VAT= models.CharField('VAT', max_length=50,null=True,blank=True)
    NID= models.CharField('NID', max_length=50,null=True,blank=True)
    IS_PAID=models.BooleanField("IsPaid",default=False)
    
    
 
