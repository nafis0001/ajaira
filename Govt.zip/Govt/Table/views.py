from django.shortcuts import render, HttpResponseRedirect,HttpResponse,render_to_response
from .models import Invoice

# Create your views here.
def index(request):
    return render(request,"index.html",{})

def register1(request):
    print("register11111111111111")
    return HttpResponseRedirect('/RegisterSeller')
def register(request):
    #print("aaaaaaaaaaaaaaaaaaaaaaaaaaa")
    return render(request,"registerseller.html",{})
def checkSeller(request):
    #return render(request,"checkseller.html",{})
    print("aaaaaaaaaaaaaaaaaaaaaaaaaaa")
    ob=Invoice.objects.all()
    return render_to_response("checkseller.html", {'obj':ob})
def checkConsumer(request):
    ob=Invoice.objects.all()
    return render_to_response("checkconsumer.html", {'obj':ob})
    #return render(request,"checkconsumer.html",{})
def register2(request):
    return render(request,"registerseller2.html",{})

def check1(request):
    return HttpResponseRedirect('/CheckSeller');

def consumer1(request):
    return HttpResponseRedirect('/CheckConsumer');
 