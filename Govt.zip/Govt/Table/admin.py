from django.contrib import admin

# Register your models here.
# Register your models here.
from .models import Customer
from .models import Customer_info
from .models import Business_info
from .models import Invoice
from .models import Vat_info

class CustomerAdmin(admin.ModelAdmin):
    list_display = ("NID","RCOUNT","PASSWORD","IS_ACTIVATED")

class Customer_infoAdmin(admin.ModelAdmin):
    list_display = ("NAME","DATE_OF_BIRTH","PHONE","ADDRESS","NID")
    
class Business_infoAdmin(admin.ModelAdmin):
    list_display = ("BUSINESS_ID","VAT_ID","PHONE","ADDRESS")

class InvoiceAdmin(admin.ModelAdmin):
    list_display=("VAT_NO","INVOICE_ID","BUSINESS_ID","DATE","PRICE","VAT","IS_PAID","NID")

class Vat_infoAdmin(admin.ModelAdmin):
    list_display=("VAT_TYPE","VAT_PERCENTAGE")
    
admin.site.register(Customer,CustomerAdmin) 
admin.site.register(Customer_info,Customer_infoAdmin) 
admin.site.register(Business_info,Business_infoAdmin) 
admin.site.register(Invoice,InvoiceAdmin)
admin.site.register(Vat_info,Vat_infoAdmin) 