"""Govt URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import include, url,patterns
from django.contrib import admin

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^Home/$','Table.views.index', name='Index'),
    url(r'^RegisterSeller','Table.views.register', name='Register'),
    url(r'^Home/RegisterSeller/$','Table.views.register1', name='Register1'),
   
    url(r'^CheckSeller','Table.views.checkSeller', name='CheckS'),
    url(r'^Home/CheckSeller/$','Table.views.check1', name='check1'),
    
    url(r'^CheckConsumer','Table.views.checkConsumer', name='CheckConsumer'),
    url(r'^Home/CheckConsumer/$','Table.views.consumer1', name='consumer1'),
    
    url(r'^RegisterConfirm','Table.views.register2', name='Confirm'),
    
]
